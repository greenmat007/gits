from mitmproxy.tools.console import master

__all__ = ["master"]
